<template>
  <div class="container">
    <h1 class="title">
      <img src="@/assets/pku_logo.png" alt="Logo" class="logo" />
      <span class="main-title">学术搜索 X-plore</span>
    </h1>
    <h2 class="sub-title">（北京大学医学部、理学部、信息科学与技术学部、工学部）</h2>
    <!-- 使用 SearchBar 组件 -->
    <SearchBar
      :query-value="query"
      :selected-category-value="selectedCategory"
      :input-width="inputWidth"
      :button-style="buttonStyle"
      :results-length="results.length"
      @update:queryValue="val => (query = val)"
      @update:selectedCategoryValue="val => (selectedCategory = val)"
      @search="handleSearch"
    />
    <!-- 使用 ResultDisplay 组件 -->
    <ResultDisplay
      :results="results"
      :columns="columns"
      :error-message="errorMessage"
      :has-searched="hasSearched"
      :is-loading="isLoading"
      :is-mobile="isMobile"
      @toggleExpand="toggleExpand"
    />
  </div>
  <footer class="footer">
    <p>版权所有©北京大学医学部学科办、北京大学计算中心</p>
  </footer>
</template>

<script lang="ts">
import { defineComponent, ref, h, onMounted } from 'vue';
import type { CSSProperties } from 'vue';
import axios from 'axios';
import {
  Button as AButton,
  Input as AInput,
  Table as ATable,
  Spin as ASpin,
  Select as ASelect,
} from 'ant-design-vue';
import SearchBar from './components/SearchBar.vue';
import ResultDisplay from './components/ResultDisplay.vue';

interface Scholar {
  name: string;
  title?: string;
  school: string;
  institute: string;
  research_area: string;
  email: string;
  office_phone: string;
  personal_homepage?: string;
  scopus?: string; 
}

export default defineComponent({
  name: 'SearchPage',
  components: {
    AButton,
    AInput,
    ATable,
    ASpin,
    ASelect,
    AOption: (ASelect as any).Option, // 使用类型断言绕过 TypeScript 的类型检查
    SearchBar,
    ResultDisplay,
  },
  setup() {
    const query = ref<string>(''); // 搜索关键词
    const selectedCategory = ref<string>('研究领域'); // 选择的分类，默认“研究领域”
    const results = ref<Scholar[]>([]); // 搜索结果
    const errorMessage = ref<string>(''); // 错误信息
    const hasSearched = ref<boolean>(false); // 标记是否已经执行过搜索
    const isLoading = ref<boolean>(false); // 标记是否正在加载
    const isMobile = ref<boolean>(false);

    const inputWidth = ref<string>('400px');
    const buttonStyle = ref<CSSProperties>({ marginLeft: '10px' });

    const mobileBreakpoint = 768;

    const adjustStyles = () => {
      if (window.innerWidth <= 480) {
        inputWidth.value = '80%';
        buttonStyle.value = { marginTop: '10px' };
      } else {
        inputWidth.value = '400px';
        buttonStyle.value = { marginLeft: '10px' };
      }

      isMobile.value = window.innerWidth <= mobileBreakpoint;
    };

    onMounted(() => {
      adjustStyles();
      window.addEventListener('resize', adjustStyles);
    });

    const columns = [
      {
        title: '序号',
        dataIndex: 'index',
        key: 'index',
        width: 65,
        align: 'center' as const,
        customRender: ({
                        index,
                      }: {
          index: number;
        }) => {
          return index + 1; // 序号从1开始
        },
      },
      {
        title: '姓名',
        dataIndex: 'name',
        key: 'name',
        width: 95,
        align: 'center' as const,
        customRender: ({
                        text,
                        record,
                      }: {
          text: string;
          record: Scholar;
        }) => {
          if (
            record.personal_homepage &&
            record.personal_homepage !== 'NA'
          ) {
            return h(
              'a',
              {
                href: record.personal_homepage,
                target: '_blank',
                style: { color: '#1f3b7b' },
              },
              text,
            );
          } else {
            return text;
          }
        },
      },
      {
        title: '职称',
        dataIndex: 'title',
        key: 'title',
        width: 80,
        align: 'center' as const,
      },
      {
        title: '学院',
        dataIndex: 'school',
        key: 'school',
        width: 100,
        align: 'center' as const,
      },
      {
        title: '所在单位',
        dataIndex: 'institute',
        key: 'institute',
        width: 120,
        align: 'center' as const,
      },
      {
        title: '研究领域',
        dataIndex: 'research_area',
        key: 'research_area',
        width: 150,
        align: 'center' as const,
      },
      {
        title: '邮箱',
        dataIndex: 'email',
        key: 'email',
        width: 200,
        align: 'center' as const,
      },
      {
        title: '办公室电话',
        dataIndex: 'office_phone',
        key: 'office_phone',
        width: 120,
        align: 'center' as const,
      },
      {
        title: '个人主页',
        dataIndex: 'personal_homepage',
        key: 'personal_homepage',
        width: 300,
        align: 'center' as const,
        customRender: ({
                        text,
                      }: {
          text: string;
          record: Scholar;
        }) => {
          if (text && text !== 'NA') {
            return h(
              'a',
              {
                href: text,
                target: '_blank',
                title: text, // 鼠标悬浮时显示完整链接
                style: {
                  color: '#1f3b7b',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  display: 'inline-block',
                  maxWidth: '300px', 
                },
              },
              text,
            );
          } else {
            return '无';
          }
        },
      },
      {
        title: 'scopus学者档案',
        dataIndex: 'scopus',
        key: 'scopus',
        width: 300,
        align: 'center' as const,
        customRender: ({
          text,
        }: {
          text: string;
        }) => {
          if (text && text !== 'NA') {
            const formattedLink = text.replace(
              /^https:\/\/www-scopus-com-\d+\.webvpn\.bjmu\.edu\.cn\//,
              'https://www.scopus.com/',
            );
            return h(
              'a',
              {
                href: formattedLink,
                target: '_blank',
                title: formattedLink,
                style: {
                  color: '#1f3b7b',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  display: 'inline-block',
                  maxWidth: '250px',
                },
              },
              formattedLink.includes('scopus.com')
                ? formattedLink 
                : `${text} (可能受限)`, 
            );
          } else {
            return '无';
          }
        },
      },
    ];

    const handleSearch = async () => {
      // 清空错误信息
      errorMessage.value = '';

      if (!query.value.trim()) {
        errorMessage.value = '请输入搜索内容！';
        return;
      }

      // 设置状态
      hasSearched.value = true;
      isLoading.value = true; // 开始加载

      results.value = []; // 清空之前的结果
      const categoryMap = {
        '研究领域': 0,
        '姓名': 1,
        '学院': 2
      };
      const categoryValue = categoryMap[selectedCategory.value as keyof typeof categoryMap];

      try {
        // 发送 POST 请求到后端，包含选定的搜索类别
        const response = await axios.post<{ results: Scholar[] }>(
          '/api/find_scholar',
          {
            query: query.value,
            category: categoryValue, // 将转换后的类别值发送到后端
          },
        );

        // 更新搜索结果
        results.value = response.data.results;

      } catch (error) {
        if (
          axios.isAxiosError(error) &&
          error.response &&
          error.response.data &&
          (error.response.data as any).error
        ) {
          errorMessage.value = (error.response.data as any).error;
        } else {
          errorMessage.value = '搜索时发生错误，请稍后重试。';
        }
      } finally {
        isLoading.value = false; // 请求结束，停止加载
      }
    };

    const expandedIndex = ref<number | null>(null);

    const toggleExpand = (index: number) => {
      expandedIndex.value = expandedIndex.value === index ? null : index;
    };

    return {
      query,
      selectedCategory,
      results,
      columns,
      errorMessage,
      hasSearched,
      isLoading,
      handleSearch,
      inputWidth,
      buttonStyle,
      isMobile,
      toggleExpand,
      expandedIndex,
    };
  },
});
</script>

<style scoped src="./assets/main.css"></style>