<template>
  <div>
    <div v-if="isLoading" class="loading-spinner">
      <a-spin tip="加载中..." />
    </div>
    <div v-if="errorMessage" class="error-message">
      <p>{{ errorMessage }}</p>
    </div>
    <div v-if="results.length === 0 && hasSearched && !errorMessage && !isLoading" class="no-results-message">
      <p>未找到匹配的结果。</p>
    </div>
    <div v-if="results.length > 0" class="results">
      <h2>搜索结果</h2>
      <p class="result-count">共找到 {{ results.length }} 条结果</p>
      <div v-if="isMobile" class="mobile-table">
        <div v-for="(item, index) in results" :key="index" class="card">
          <h3 class="name">{{ item.name }}</h3>
          <div class="info-bar">
            <p class="expand" @click="toggleExpand(index)">
              {{ expandedIndex === index ? '收起详情' : '展开详情' }}
            </p>
            <p>{{ item.school }}</p>
          </div>
          <div v-if="expandedIndex === index" class="details">
            <p><span style="font-weight: bold;">职称：</span> {{ item.title }}</p>
            <p><span style="font-weight: bold;">所在单位：</span> {{ item.institute }}</p>
            <p><span style="font-weight: bold;">研究领域：</span> {{ item.research_area }}</p>
            <p><span style="font-weight: bold;">办公电话：</span> {{ item.office_phone }}</p>
            <p><span style="font-weight: bold;">电子邮件：</span> {{ item.email }}</p>
            <p><span style="font-weight: bold;">个人主页：</span>
              <a :href="item.personal_homepage" target="_blank" style="color: blue; text-decoration: underline;">
                点击访问
              </a>
            </p>
          </div>
        </div>
      </div>
      <div v-else class="table-responsive">
        <a-table 
          :columns="columns" 
          :data-source="results" 
          :row-key="record => record.email || record.name"
          :pagination="false" 
          bordered 
          :scroll="{ x: 'max-content' }" 
          table-layout="auto"
        />
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';
import type { CSSProperties } from 'vue';
import { Table as ATable, Spin as ASpin } from 'ant-design-vue';
import type { ColumnType, ColumnGroupType } from 'ant-design-vue/es/table';

interface Scholar {
  name: string;
  title?: string;
  school: string;
  institute: string;
  research_area: string;
  email: string;
  office_phone: string;
  personal_homepage?: string;
}

export default defineComponent({
  name: 'ResultDisplay',
  components: {
    ATable,
    ASpin,
  },
  props: {
    results: {
      type: Array as () => Scholar[],
      required: true,
    },
    columns: {
      type: Array as () => (ColumnType<Scholar> | ColumnGroupType<Scholar>)[],
      required: true,
    },
    errorMessage: {
      type: String,
      required: true,
    },
    hasSearched: {
      type: Boolean,
      required: true,
    },
    isLoading: {
      type: Boolean,
      required: true,
    },
    isMobile: {
      type: Boolean,
      required: true,
    },
  },
  emits: ['toggleExpand'],
  setup(props, { emit }) {
    const expandedIndex = ref<number | null>(null);

    const toggleExpand = (index: number) => {
      expandedIndex.value = expandedIndex.value === index ? null : index;
      emit('toggleExpand', index);
    };

    return {
      expandedIndex,
      toggleExpand,
    };
  },
});
</script>

<style scoped>
.table-responsive {
  width: 100%;
  overflow-x: auto;
  max-height: 500px;
  overflow-y: scroll;
}

.table-responsive::-webkit-scrollbar {
  display: none; /* 隐藏滚动条 */
}

.ant-table {
  width: 100%;
  min-width: 100%; /* 确保表格宽度与容器一致 */
}
</style>