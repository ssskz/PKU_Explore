<template>
  <div class="search-group">
    <div class="search-controls">
      <ASelect
        v-model:value="selectedCategory"
        :style="{ width: '100px', marginRight: '10px' }"
        @change="handleCategoryChange"
      >
        <AOption value="研究领域">研究领域</AOption>
        <AOption value="姓名">姓名</AOption>
        <AOption value="学院">学院</AOption>
      </ASelect>
      <AInput
        v-model:value="query"
        placeholder="请输入搜索内容..."
        @keyup.enter="handleSearch"
        :style="{ width: inputWidth }"
      />
      <AButton type="primary" @click="handleSearch" :style="buttonStyle">
        搜索
      </AButton>
    </div>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref, watch } from 'vue';
import {
  Button as AButton,
  Input as AInput,
  Select as ASelect,
} from 'ant-design-vue';
import type { SelectValue } from 'ant-design-vue/es/select';

export default defineComponent({
  name: 'SearchBar',
  components: {
    AButton,
    AInput,
    ASelect,
    AOption: (ASelect as any).Option,
  },
  props: {
    queryValue: {
      type: String,
      required: true,
    },
    selectedCategoryValue: {
      type: String,
      required: true,
    },
    inputWidth: {
      type: String,
      required: true,
    },
    buttonStyle: {
      type: Object,
      required: true,
    },
    resultsLength: {
      type: Number,
      required: true,
    },
  },
  emits: ['update:queryValue', 'update:selectedCategoryValue', 'search'],
  setup(props, { emit }) {
    const query = ref<string>(props.queryValue);
    const selectedCategory = ref<string>(props.selectedCategoryValue);

    // 监听 query 和 selectedCategory 的变化，同步到父组件
    watch(query, (newVal) => emit('update:queryValue', newVal));
    watch(selectedCategory, (newVal) => emit('update:selectedCategoryValue', newVal));

    const handleSearch = () => {
      emit('search');
    };

    const handleCategoryChange = (value: SelectValue) => {
      if (typeof value === 'string') {
        selectedCategory.value = value;
      }
    };

    return {
      query,
      selectedCategory,
      handleSearch,
      handleCategoryChange,
    };
  },
});
</script>